#include "CPonto.h"
#include <iostream>

using namespace std;

int main(){
    CPonto a;
    cout << a;
    a++;
    cout << a;
    ++a;
    cout << a;
}