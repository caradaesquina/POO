#include "triangulo.h"

int main(){
	TrianguloRet triangulo(1,10,1);
	triangulo.todos100();

}