#ifndef TRIANGULO_H
#define TRIANGULO_H

class TrianguloRet{
	private:
		int m_a, m_b, m_c;	
	
	public:		
		TrianguloRet() {};
		TrianguloRet(int, int, int);
		~TrianguloRet() {};
			
		void todos100();
};

#endif