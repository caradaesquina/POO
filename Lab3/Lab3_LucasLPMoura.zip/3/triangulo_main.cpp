#include "triangulo_retangulo.h"
#include <iostream>

using namespace std;

int main(){
    trianguloRetangulo::getAllTriangulosRetangulosLessThan200();
    return 0;
}